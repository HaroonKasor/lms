/*** 8016 ***/


var scoid='968';
var direction = ' ';
var direction_sound = '';
var showanswer = false;
var showanswer_no = 0;
var offline = false;
var shuffle_question = false;
var score_save = true;
var score = 0;
var testformat= 1;
var thai = true;
var system_message = '';
var random_choice = false;
var random_question = 0;
var percentmasteryscore = 80;
var random_question_array = [];
var question_wrong = [];
var question_answer = [];

var tf_label_true = 'True';
var tf_label_false = 'False';

var suspend_data = 0;
var usescorm = false;

if((usescorm) && (showanswer) && (showanswer_no > 0)){
	suspend_data = parent.doLMSGetValue("cmi.suspend_data");

	if(isNaN(suspend_data) || (suspend_data == null) || (suspend_data=='')) suspend_data = 0;
	suspend_data++;

	if(suspend_data){
		/*
		if((!isNaN(suspend_data)) && (suspend_data != null) && (suspend_data != ''))
			showanswer = (showanswer_no <= parseInt(suspend_data))?true:false;
		else
			showanswer = false;
		*/
		showanswer = ((!isNaN(suspend_data)) && (suspend_data != null) && (suspend_data != ''))?((showanswer_no <= parseInt(suspend_data))?true:false):false;
	}
	else
		showanswer = false;
}
else{
	if(showanswer_no > 1) showanswer = false;
}



var question = new Array();
var question_score = new Array();
var choice = new Array();
var question_comment = new Array();
var question_origin_index = new Array();
var question_origin_name = new Array();

question_origin_name[0]='บทที่ 1 ';
question_origin_name[1]='บทที่ 2 ';
question_origin_name[2]='บทที่ 3 ';
question_origin_name[3]='บทที่ 4  ';
question_origin_name[4]='บทที่ 5 ';
question_origin_name[5]='บทที่ 6 ';
question_origin_name[6]='บทที่ 7 ';
question_origin_name[7]='บทที่ 8 ';
question_origin_name[8]='บทที่ 9 ';
question_origin_name[9]='บทที่ 10 ';
question_origin_name[10]='บทที่ 11  ';
question_origin_name[11] = 'บทที่ 12';
question_origin_name[12] = 'บทที่ 13';
question_origin_name[13] = 'บทที่ 14';
question_origin_name[14] = 'บทที่ 15';
question_origin_name[15] = 'บทที่ 16';
question_origin_name[16] = 'บทที่ 17';
question_origin_name[17] = 'บทที่ 18';
question_origin_name[18] = 'บทที่ 19';
question_origin_name[19] = 'บทที่ 20';
question_origin_name[20] = 'บทที่ 21';
question_origin_name[21] = 'บทที่ 22';





//* Question: 1********************
question[0] = 'ข้อใดคือกลุ่มผู้ปฏิบัติงานที่มีความเสี่ยงสูงที่ได้รับผลกระทบจากสภาวะโลกร้อน ';
question_score[0] = '1';
choice[0] = new Array();

//* Question: 2********************
question[1] = 'ข้อใดเป็นผลกระทบจากอุณหภูมิที่มีความร้อนสูงมากผิดปกติ ';
question_score[1] = '1';
choice[1] = new Array();

//* Question: 3********************
question[2] = 'ข้อใดเป็นแนวทางปฏิบัติการรับมือ ภัยแล้งระดับชุมชน';
question_score[2] = '1';
choice[2] = new Array();

//* Question: 4********************
question[3] = 'ข้อใดเป็นแนวทางการรับมือต่อผลกระทบจากภัยแล้งอย่างยั่งยืน';
question_score[3] = '1';
choice[3] = new Array();

//* Question: 5********************
question[4] = 'ข้อใดไม่ใช่วิถีการทำนาที่ยั่งยืนและเป็นมิตรกับสิ่งแวดล้อม ';
question_score[4] = '1';
choice[4] = new Array();

//* Question: 6********************
question[5] = 'ข้อใดเป็นผลกระทบที่สำคัญของภาวะโลกร้อนต่อสาขาการเกษตร';
question_score[5] = '1';
choice[5] = new Array();

//* Question: 7********************
question[6] = 'ภัยพิบัติใดที่ไม่ได้เกิดขึ้นจากธรรมชาติ';
question_score[6] = '1';
choice[6] = new Array();

//* Question: 8********************
question[7] = 'ข้อใดไม่ใช่มาตรการจัดการน้ำ อุทกภัย และภัยพิบัติ โดยไม่ใช้สิ่งก่อสร้าง ';
question_score[7] = '1';
choice[7] = new Array();

//* Question: 9********************
question[8] = 'ข้อใดไม่ใช่แนวทางปรับตัวของโครงการท่องเที่ยวเชิงเกษตรชุมชนบ้านปง';
question_score[8] = '1';
choice[8] = new Array();

//* Question: 10********************
question[9] = 'นักท่องเที่ยวสามารถลดการปล่อยก๊าซเรือนกระจกได้อย่างไร';
question_score[9] = '1';
choice[9] = new Array();

//* Question: 11********************
question[10] = 'การสูญเสียของอาหารเกิดขึ้นในกระบวนการใด';
question_score[10] = '1';
choice[10] = new Array();

//* Question: 12********************
question[11] = 'หนอน BSF ในการจัดการขยะอินทรีย์ มาจากแมลงชนิดใด';
question_score[11] = '1';
choice[11] = new Array();


//* Question: 13********************
question[12] = 'ชุมชนมีวิธีป้องกันไฟป่าได้อย่างไร';
question_score[12] = '1';
choice[12] = new Array();

//* Question: 14********************
question[13] = 'ไฟป่า ก่อให้เกิดผลกระทบต่อโลกร้อนอย่างไร';
question_score[13] = '1';
choice[13] = new Array();

//* Question: 15********************
question[14] = 'ภาคส่วนที่ปล่อยก๊าซเรือนกระจกมากที่สุดของประเทศไทย';
question_score[14] = '1';
choice[14] = new Array();

//* Question: 16********************
question[15] = 'เป้าหมายการลดก๊าซเรือนกระจกที่ประเทศกำหนด (NDC) ในปี ค.ศ. 2030 ';
question_score[15] = '1';
choice[15] = new Array();

//* Question: 17********************
question[16] = 'แผนการปรับตัวต่อการเปลี่ยนแปลงสภาพภูมิอากาศแห่งชาติ พ.ศ.2561-2580 ในสาขาการจัดการทรัพยากรธรรมชาติมีแนวทางในการจัดการอย่างไร';
question_score[16] = '1';
choice[16] = new Array();

//* Question: 18********************
question[17] = 'ข้อใดต่อไปนี้เป็นการใช้ Nature-based Solutions (NbS) ในการปรับตัวต่อผลกระทบจากการเปลี่ยนแปลงสภาพภูมิอากาศ';
question_score[17] = '1';
choice[17] = new Array();

//* Question: 19********************
question[18] = 'ภาคส่วนใดเป็นภาคส่วนที่มีศักยภาพในการดูดกลับการปล่อยก๊าซเรือนกระจก เพราะอะไร ';
question_score[18] = '1';
choice[18] = new Array();

//* Question: 20********************
question[19] = 'ข้อใดไม่ใช่การปล่อยก๊าซเรือนกระจกที่เกิดจากกิจกรรมของมนุษย์';
question_score[19] = '1';
choice[19] = new Array();

//* Question: 21********************
question[20] = 'ป่าชนิดใดที่สามารถกักเก็บคาร์บอนได้ดีที่สุด';
question_score[20] = '1';
choice[20] = new Array();

//* Question: 22********************
question[21] = 'ข้อใดไม่ใช่ต้นไม้ที่เหมาะสมสำหรับการปลูกเพื่อกักเก็บคาร์บอน ';
question_score[21] = '1';
choice[21] = new Array();





//* Answer: 1********************
choice[0][0] = new Array();
choice[0][0][0] = 'ผู้ปฏิบัติงานในอาคารที่มีการระบายอากาศเพียงพอ ';
choice[0][0][1] = '0';

choice[0][1] = new Array();
choice[0][1][0] = 'ผู้ปฏิบัติงานกลางแจ้ง ';
choice[0][1][1] = '1';

choice[0][2] = new Array();
choice[0][2][0] = 'ผู้ปฏิบัติงานในวิสาหกิจขนาดใหญ่ ';
choice[0][2][1] = '0';

choice[0][3] = new Array();
choice[0][3][0] = 'ไม่มีข้อใดถูก';
choice[0][3][1] = '0';


//* Answer: 2********************
choice[1][0] = new Array();
choice[1][0][0] = 'โรคลมแดด ';
choice[1][0][1] = '0';

choice[1][1] = new Array();
choice[1][1][0] = 'ปัญหาสุขภาพจิต ';
choice[1][1][1] = '0';

choice[1][2] = new Array();
choice[1][2][0] = 'โรคไต ';
choice[1][2][1] = '0';

choice[1][3] = new Array();
choice[1][3][0] = 'ถูกทุกข้อ';
choice[1][3][1] = '1';


//* Answer: 3********************
choice[2][0] = new Array();
choice[2][0][0] = 'สร้างระบบกักเก็บน้ำ';
choice[2][0][1] = '0';

choice[2][1] = new Array();
choice[2][1][0] = 'ฟื้นฟูป่าไม้และแหล่งน้ำ';
choice[2][1][1] = '0';

choice[2][2] = new Array();
choice[2][2][0] = 'ปลูกพืชทนแล้ง';
choice[2][2][1] = '0';

choice[2][3] = new Array();
choice[2][3][0] = 'ถูกทุกข้อ';
choice[2][3][1] = '1';


//* Answer: 4********************
choice[3][0] = new Array();
choice[3][0][0] = 'เฝ้าระวังและเตือนภัยล่วงหน้า';
choice[3][0][1] = '0';

choice[3][1] = new Array();
choice[3][1][0] = 'การประเมินความเสี่ยงจากภัยแล้ง';
choice[3][1][1] = '0';

choice[3][2] = new Array();
choice[3][2][0] = 'จัดทำมาตรการความเสี่ยงและแผนการรับมือภัยแล้งระดับชาติ';
choice[3][2][1] = '0';

choice[3][3] = new Array();
choice[3][3][0] = 'ถูกทุกข้อ';
choice[3][3][1] = '1';


//* Answer: 5********************
choice[4][0] = new Array();
choice[4][0][0] = 'การปรับพื้นที่นาด้วยระบบเลเซอร์';
choice[4][0][1] = '0';

choice[4][1] = new Array();
choice[4][1][0] = 'การทำนาแบบเปียกสลับแห้ง';
choice[4][1][1] = '0';

choice[4][2] = new Array();
choice[4][2][0] = 'การใช้ปุ๋ยตามค่าวิเคราะห์ดิน';
choice[4][2][1] = '0';

choice[4][3] = new Array();
choice[4][3][0] = 'การเผาฟางและตอซัง';
choice[4][3][1] = '1';


//* Answer: 6********************
choice[5][0] = new Array();
choice[5][0][0] = 'ราคาพืชผลการเกษตรตกต่ำ';
choice[5][0][1] = '0';

choice[5][1] = new Array();
choice[5][1][0] = 'ความไม่แน่นอนในช่วงเวลาและพื้นที่การเพาะปลูก';
choice[5][1][1] = '1';

choice[5][2] = new Array();
choice[5][2][0] = 'เกษตรกรขาดพื้นที่ทำกิน';
choice[5][2][1] = '0';

choice[5][3] = new Array();
choice[5][3][0] = 'เกิดน้ำท่วมฉับพลัน';
choice[5][3][1] = '0';

//* Answer: 7********************
choice[6][0] = new Array();
choice[6][0][0] = 'พายุ';
choice[6][0][1] = '0';

choice[6][1] = new Array();
choice[6][1][0] = 'สึนามิ';
choice[6][1][1] = '0';

choice[6][2] = new Array();
choice[6][2][0] = 'แผ่นดินไหว';
choice[6][2][1] = '0';

choice[6][3] = new Array();
choice[6][3][0] = 'การปล่อยก๊าซเรือนกระจก';
choice[6][3][1] = '1';



//* Answer: 8********************
choice[7][0] = new Array();
choice[7][0][0] = 'การพยากรณ์และเตือนภัย';
choice[7][0][1] = '1';

choice[7][1] = new Array();
choice[7][1][0] = 'แผนรับมือน้ำท่วม';
choice[7][1][1] = '0';

choice[7][2] = new Array();
choice[7][2][0] = 'แผนบรรเทาทุกข์';
choice[7][2][1] = '0';

choice[7][3] = new Array();
choice[7][3][0] = 'การสร้างอ่างเก็บน้ำ';
choice[7][3][1] = '0';


//* Answer: 9********************
choice[8][0] = new Array();
choice[8][0][0] = 'ส่งเสริมการท่องเที่ยวในสวนเกษตรอินทรีย์ เช่น การเก็บผลผลิตสด';
choice[8][0][1] = '0';

choice[8][1] = new Array();
choice[8][1][0] = 'จัดกิจกรรมเรียนรู้การปลูกผักและเลี้ยงสัตว์แบบยั่งยืน';
choice[8][1][1] = '0'; 

choice[8][2] = new Array();
choice[8][2][0] = 'สร้างเครือข่ายการขายสินค้าผ่านออนไลน์เพื่อเสริมรายได้';
choice[8][2][1] = '0';

choice[8][3] = new Array();
choice[8][3][0] = 'จัดทำเส้นทางจักรยานและเดินเท้าผ่านพื้นที่ธรรมชาติ';
choice[8][3][1] = '1';


//* Answer: 10********************
choice[9][0] = new Array();
choice[9][0][0] = 'เดินทางโดยระบบขนส่งสาธารณะ';
choice[9][0][1] = '0';

choice[9][1] = new Array();
choice[9][1][0] = 'ลดขยะพาสติกและหลีกเลี่ยงการใช้พลาสติกครั้งเดียวทิ้ง';
choice[9][1][1] = '0'; 

choice[9][2] = new Array();
choice[9][2][0] = 'เลือกที่พักที่ให้ความสำคัญกับความยั้งยืนด้านสิ่งแวดล้อม';
choice[9][2][1] = '0';

choice[9][3] = new Array();
choice[9][3][0] = 'ถูกทุกข้อ';
choice[9][3][1] = '1';



//* Answer: 11********************
choice[10][0] = new Array();
choice[10][0][0] = 'เศษผลไม้ที่มีรสเปรี้ยว';
choice[10][0][1] = '0'; 

choice[10][1] = new Array();
choice[10][1][0] = 'การเก็บเกี่ยวและการเก็บรักษา';
choice[10][1][1] = '0';

choice[10][2] = new Array();
choice[10][2][0] = 'การแปรรูปและบรรจุ';
choice[10][2][1] = '0';

choice[10][3] = new Array();
choice[10][3][0] = 'ถูกทุกข้อ';
choice[10][3][1] = '1';

//* Answer: 12********************
choice[11][0] = new Array();
choice[11][0][0] = 'แมลงวัน ';
choice[11][0][1] = '0';

choice[11][1] = new Array();
choice[11][1][0] = 'แมลงทู';
choice[11][1][1] = '0';

choice[11][2] = new Array();
choice[11][2][0] = 'แมลงวันทอง';
choice[11][2][1] = '0';

choice[11][3] = new Array();
choice[11][3][0] = 'แมลงวันลาย';
choice[11][3][1] = '1'; 

//* Answer: 13********************
choice[12][0] = new Array();
choice[12][0][0] = 'ทำแนวกันไฟ';
choice[12][0][1] = '1'; 

choice[12][1] = new Array();
choice[12][1][0] = 'ปลูกพืชหมุนเวียน';
choice[12][1][1] = '0';

choice[12][2] = new Array();
choice[12][2][0] = 'ขุดสระกักเก็บน้ำ';
choice[12][2][1] = '0';

choice[12][3] = new Array();
choice[12][3][0] = 'ทำฝนเทียม';
choice[12][3][1] = '0';



//* Answer: 14********************
choice[13][0] = new Array();
choice[13][0][0] = 'ทำลายต้นไม้';
choice[13][0][1] = '0'; 

choice[13][1] = new Array();
choice[13][1][0] = 'สร้างฝุ่น PM2.5';
choice[13][1][1] = '0';

choice[13][2] = new Array();
choice[13][2][0] = 'ปล่อยก๊าซเรือนกระจก';
choice[13][2][1] = '0';

choice[13][3] = new Array();
choice[13][3][0] = 'ถูกทุกข้อ';
choice[13][3][1] = '1';



//* Answer: 15********************
choice[14][0] = new Array();
choice[14][0][0] = 'ภาคพลังงาน  ';
choice[14][0][1] = '1';

choice[14][1] = new Array();
choice[14][1][0] = 'ภาคเกษตร ';
choice[14][1][1] = '0';

choice[14][2] = new Array();
choice[14][2][0] = 'ภาคของเสีย ';
choice[14][2][1] = '0'; 

choice[14][3] = new Array();
choice[14][3][0] = 'ภาคอุตสาหกรรมและการใช้ผลิตภัณฑ์';
choice[14][3][1] = '0';

//* Answer: 16********************
choice[15][0] = new Array();
choice[15][0][0] = 'ลดก๊าซเรือนกระจกร้อยละ 10 - 20 ';
choice[15][0][1] = '0';

choice[15][1] = new Array();
choice[15][1][0] = 'ลดก๊าซเรือนกระจกร้อยละ 40 - 50 ';
choice[15][1][1] = '0'; 

choice[15][2] = new Array();
choice[15][2][0] = 'ลดก๊าซเรือนกระจกร้อยละ 50 - 60 ';
choice[15][2][1] = '0';

choice[15][3] = new Array();
choice[15][3][0] = 'ลดก๊าซเรือนกระจกร้อยละ 30 - 40';
choice[15][3][1] = '1';

//* Answer: 17 ********************
choice[16][0] = new Array();
choice[16][0][0] = 'การจัดการระบบนิเวศบนบก';
choice[16][0][1] = '0';

choice[16][1] = new Array();
choice[16][1][0] = 'การจัดการพื้นที่ชุ่มน้ำ';
choice[16][1][1] = '0';

choice[16][2] = new Array();
choice[16][2][0] = 'การจัดการระบบนิเวศทางทะเลและชายฝั่ง';
choice[16][2][1] = '0';

choice[16][3] = new Array();
choice[16][3][0] = 'ถูกทุกข้อ';
choice[16][3][1] = '1'; 


//* Answer: 18 ********************
choice[17][0] = new Array();
choice[17][0][0] = 'การใช้ประโยชน์จากพื้นที่ชุ่มน้ำเพื่อทำหน้าที่เป็นฟองน้ำรองรับและชะลอการไหลของน้ำ';
choice[17][0][1] = '1'; 

choice[17][1] = new Array();
choice[17][1][0] = 'การสร้างฝายกั้นน้ำ';
choice[17][1][1] = '0';

choice[17][2] = new Array();
choice[17][2][0] = 'การใช้เทคโนโลยีดักจับคาร์บอนไดออกไซด์';
choice[17][2][1] = '0';

choice[17][3] = new Array();
choice[17][3][0] = 'สร้างกำแพงป้องกันการกัดเซาะชายฝั่ง';
choice[17][3][1] = '0';


//* Answer: 19 ********************
choice[18][0] = new Array();
choice[18][0][0] = 'ภาคป่าไม้ เนื่องจากสามารถดูดกลับ CO2 และสะสมเป็นชีวมวลในเนื้อไม้ได้';
choice[18][0][1] = '1'; 

choice[18][1] = new Array();
choice[18][1][0] = 'ภาคอุตสาหกรรม เนื่องจากสามารถดูดกลับ CO2 และเพิ่มปริมาณการผลิต';
choice[18][1][1] = '0';

choice[18][2] = new Array();
choice[18][2][0] = 'ภาคการจัดการเมือง เนื่องจากสามารถดูดกลับ CO2 และสะสมในแต่ละจังหวัด';
choice[18][2][1] = '0';

choice[18][3] = new Array();
choice[18][3][0] = 'ภาคการคมนาคมขนส่ง เนื่องจากสามารถดูดกลับ CO2 และเพิ่มจำนวนรถใช้งานได้เพียงพอ';
choice[18][3][1] = '0';


//* Answer: 20********************
choice[19][0] = new Array();
choice[19][0][0] = 'การตัดไม้ทำลายป่า';
choice[19][0][1] = '0';

choice[19][1] = new Array();
choice[19][1][0] = 'การเผาไหม้เชื้อเพลิงจากโรงงานอุตสาหกรรม';
choice[19][1][1] = '0';

choice[19][2] = new Array();
choice[19][2][0] = 'ภูเขาไฟระเบิด';
choice[19][2][1] = '1';

choice[19][3] = new Array();
choice[19][3][0] = 'การทำนาข้าว';
choice[19][3][1] = '0';


//* Answer: 21********************
choice[20][0] = new Array();
choice[20][0][0] = 'ป่าที่เติบโตตามธรรมชาติและมีพันธุ์พืชหลากหลายชนิด';
choice[20][0][1] = '1';

choice[20][1] = new Array();
choice[20][1][0] = 'ป่าที่เป็นพืชชนิดเดี่ยว';
choice[20][1][1] = '0';

choice[20][2] = new Array();
choice[20][2][0] = 'ป่าที่ปลูกขึ้นในเมือง';
choice[20][2][1] = '0';

choice[20][3] = new Array();
choice[20][3][0] = 'ถูกทุกข้อ';
choice[20][3][1] = '0';


//* Answer: 22********************
choice[21][0] = new Array();
choice[21][0][0] = 'พะยูง';
choice[21][0][1] = '0';

choice[21][1] = new Array();
choice[21][1][0] = 'ยางนา';
choice[21][1][1] = '0';

choice[21][2] = new Array();
choice[21][2][0] = 'มะม่วง';
choice[21][2][1] = '1'; 

choice[21][3] = new Array();
choice[21][3][0] = 'ตะเคียนทอง';
choice[21][3][1] = '0';





var fb_range = [];


var outChoice = "";
var outAns = "";
var cChoice = "กขคงจ";
//var cChoice = "abcde";
var cNo=new Array("0");
//var cNo=new Array("0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30");
//var cNo=new Array("๐","๑","๒","๓","๔","๕","๖","๗","๘","๙","๑๐");
var qid = 1;
var chkans2 = false;

if(random_question <= 0) random_question = question.length;

var i=1
for (; i <= random_question; i++) {
  cNo.push(i);
} 


function genQuestion(no,a,chkans,ans){
	
	if(chkans){
		chkans2 = true;
		var txtq = '<div id=q'+no+' name=q'+no+'  style="position:absolute; left:2cm; top:60px; display :none; width:90%;overflow-y:auto;height:390px">';
	}else{
		var txtq = '<div id=q'+no+' name=q'+no+' style="position:absolute; left:2cm; top:60px; display :none; width:90%;overflow-y:auto;height:390px" >';
//		var txtq = '<div id=q'+no+' name=q'+no+' style="position:absolute; left:2.5cm; top:2.5cm; visibility:visible">';
	}

	
		txtq += '<table width="100%" border="0" cellspacing="10" cellpadding="4">';
	if(question[a]){
		
		txtq += '<tr> ';
//		txtq += '<td  align="left" valign=top><img width=20 src=asset/spacer.gif></td>';
//		txtq += '<IMG SRC="asset/speaker.png" WIDTH="30" HEIGHT="30" BORDER="0" ALT="ฟังเสียง"  style="cursor: pointer" onclick="qPlayer(\''+no+'\')">';
//		txtq += '<strong><font size="6" face="Tahoma">'+cNo[no]+'.</font></strong></td>';
//	if(no==1) txtq += '<td valign="bottom"><font size="6" face="Tahoma">';
		txtq += '<td valign="top"><span><font color ="#3A3F99"><font size="6" face="Tahoma">';
		txtq += ' '+cNo[no]+'. ';
		txtq += question[a];
		txtq += '</font></span></td>';
		txtq += '</tr>';

		bgc = "#F5F5F5";
		if (no%2) bgc = "#E5E9E9";

		if(chkans){
			outChoice +=  '<tr id="tq'+no+'" bgcolor="'+bgc+'" onclick="showhide('+no+');showbg('+no+')" ><td width="25" align="center"><div id="cho_'+no+'" style="color: #000000;font-family:Tahoma; font-size: 24">'+cNo[no]+'.</div></td>';
		}else{
			outChoice +=  '<tr id="tq'+no+'" bgcolor="'+bgc+'" onclick="showhide('+no+');" ><td width="25" align="center"><div id="cho_'+no+'" style="color: #000000;font-family:Tahoma; font-size: 24">'+cNo[no]+'.</div></td>';
		}

		var correct = false;
		var correctChoice = 0;
		var txtch = '<table width="100%" border="0" cellspacing="2" cellpadding="4">';
		for(c=0;c<choice[a].length;c++)
		{
			var ch_radio = '<font size="6" face="Tahoma">'+cChoice.charAt(c)+'.</font>';
			if(chkans){
//				outChoice +=  '<td align="center"><input type="radio" name="ch_'+no+'" value="'+c+'" class="bigButton"  ';
				outChoice +=  '<td align="center"><span id="tch_'+no+'_'+c+'" name="tch_'+no+'_'+c+'" > ';
				txtch += '<tr valign="middle"> ';
			}else{
//				outChoice +=  '<td align="center"><input type="radio" name="ch_'+no+'" value="'+c+'" onClick="setAns('+no+','+c+')"   class="bigButton" ';
				outChoice +=  '<td align="center" onClick="setAns('+no+','+c+')"><input type="radio" name="ch_'+no+'" value="'+c+'" style="position:absolute; display :none"><span id="tch_'+no+'_'+c+'" name="tch_'+no+'_'+c+'" style="cursor: pointer;"><img src=asset/c.gif>';
				txtch += '<tr valign="middle"   > ';
			}
			
//			var ch_radio = '<input type="radio" name="ch_'+no+'" value="'+c+'"';

			outAns = "bgimage";
			if(chkans){
				if(ans==c){
//					outChoice +=' checked';
					outChoice +='<img src=asset/m.gif>';
//					outAns += 'document.getElementById(\'ch_'+no+'_'+c+'\').style.backgroundImage = "url(asset/ans.gif)"; ';
					outAns = "bgimage1";


					if(choice[a][c][1] == 1){
//						score+=parseInt(question_score[a]);  
						score+=1;			  /// ---------------- fix ข้อละคะแนน = 2
						correct = true;
						correctChoice = c;
					}
				txtch += '<td width=17 align="center" valign="top"><img src=asset/';
				txtch += (correct)?'1':'0'; 
				txtch += '.png style="float:left;margin-top:3px;"></td>';

				}
				else
				{
//					outChoice += ' disabled';
					outChoice +='<img width=21 src=asset/spacer.gif>';
					txtch += '<td width=17 align="center" valign="top">';
					if(showanswer){
						if(choice[a][c][1] == 1){
							txtch += '<img src=asset/1.png  style="float:left;margin-top:3px;">';
							//ch_radio = '<img src=asset/arrow.gif>';
							choice[a][c][0] = '<font color=GREEN>'+choice[a][c][0]+'</font>';
							correctChoice = c;
						}
					}
					if(choice[a][c][1] == 1){
						correctChoice = c;
					}
					txtch += '</td>';
				}
			}else{
					txtch += '<td width=17 align="center" valign="top"><img src=asset/spacer.gif  width=24px style="float:left;margin-top:3px;"></td>';
			}

			outChoice += '</span></td>';
			
			var answer_icon = '';
			if(chkans){
				answer_icon = '<img src=asset/';
				answer_icon += (correct)?'1':'0';
				answer_icon += '.png>';
			}
		
//			txtch += '<td width="30" valign="top"><IMG SRC="asset/spacer.gif" WIDTH="30" HEIGHT="30" BORDER="0" ALT="ฟังเสียง"  style="cursor: pointer" onclick="chPlayer(\''+no+'_'+(parseInt(c)+1)+'\')"></td>';
			txtch += '<td width="25" align="center"  valign="top" class="'+ outAns +'" name="ch_'+no+'_'+c+'" id="ch_'+no+'_'+c+'" onClick="setAns('+no+','+c+')" style="cursor: pointer">';

			txtch += ch_radio;
			txtch += '</td>';
			txtch += '<td valign="top"><font color ="#1F1F1F"><font size="6" face="Tahoma">';
			txtch += choice[a][c][0];
			txtch += '</font></td>';
			txtch += '</tr>';
		}
		txtch += '</table>';

//		txtq += '<tr><td align="center">'+answer_icon+'</td>';
//		txtq += '<tr><td align="center">&nbsp;</td>';
		txtq += '<tr><td valign="top" colspan="2">';
		txtq += txtch;
		txtq += '</td></tr>';
		if (chkans) {
			outChoice += '<td align="center">'+answer_icon+'</td></tr>';
			if(!correct){
				question_wrong.push(a);
			}
			question_answer.push([parseInt(ans),correctChoice]);
		}else{
			outChoice += '</td></tr>';
		}
	
	}

	txtq += '</table>';
	//txtq += '<div><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span onclick=\"javascript: showhide(\'66\')\" style=\"cursor: pointer\"><IMG SRC=\"asset/prev.gif\" BORDER=\"0\" ALT=\"ย้อนกลับ\" width=25 height=25></span>&nbsp;&nbsp;&nbsp;<span onclick=\"javascript: showhide(\'99\')\" style=\"cursor: pointer\"><IMG SRC=\"asset/go.gif\" BORDER=\"0\" ALT=\"ถัดไป\" width=25 height=25></span></div>';
	txtq += '</div>';
//alert(txtq);
//alert(outChoice);
	return txtq;
}

		function checkAnswer(frm){
			var chr = checkRadio(frm);
			if(chr=="0")
			{

				var el = frm.elements; 
				var sel = '';
				var sel2 = new Array();
				var s = 0;
				for(var i = 0 ; i < el.length ; ++i) { 
					if(el[i].type == "radio") {   
						var radiogroup = el[el[i].name];   
						sel2[s] = el[i].name;
						var itemchecked = false;  
						for(var j = 0 ; j < radiogroup.length ; ++j) {    
							if(radiogroup[j].checked) {	 

								if(s > 0)
								{
									if(sel2[(s-1)] != el[i].name)
									{						
										if(sel == '') sel = radiogroup[j].value; else sel += ':'+radiogroup[j].value;
									}
								}
								else
								{
									if(sel == '') sel = radiogroup[j].value; else sel += ':'+radiogroup[j].value;
								}
								s++;
							}   
						}   
					} 
				} 


				if(sel == '')
				{
					alert(system_message['mustdoquiz']);
				}
				else
				{
					var sel3 = sel.split(':');
					var text_ans = '';
					var e = 1;
					var txt_show = '';
					var divtst = document.getElementById("divTest");
					divtst.innerHTML = "";

//					document.write('<style type="text/css">.bgimage { background-image: url(asset/spacer.gif); background-repeat: no-repeat; background-position: top; font-family:"Tahoma"; font-size: 28 } .choice {cursor: pointer}</style>');
//document.write('<style type="text/css">.bgimage { background-image: url(asset/spacer.gif); background-repeat: no-repeat; background-position: top; font-family:Tahoma; font-size: 24 } .choice {cursor: pointer} @font-face {    font-family: \'Tahoma\';    src: url(\'Tahoma_bold-webfont.eot\');    src: url(\'Tahoma_bold-webfont.eot?#iefix\') format(\'embedded-opentype\'),         url(\'Tahoma_bold-webfont.woff\') format(\'woff\'),         url(\'Tahoma_bold-webfont.ttf\') format(\'truetype\'),         url(\'Tahoma_bold-webfont.svg#Tahoma\') format(\'svg\');    font-weight: normal;    font-style: normal;}font{	font-family: \'Tahoma\';	font-size: 24;}.bigButton{	width: 28px; height: 28px;cursor: pointer;}</style>');

					if(showanswer)
//						document.write('<font size=4 face="Tahoma" color=#FF0000> ( '+system_message['remark']+' ) </font><br>&nbsp;');

//-----1----???????????????????
						outChoice = "";
						//divtst.innerHTML += '<div id="divTest2" style="position:absolute;left:0.0cm; top:0.0cm; width:100% " >';
						divtst.innerHTML += '<table width="100%" border="0" cellspacing="0" cellpadding="2">';
						divtst.innerHTML += '  <tr bgcolor=#FFFFF> ';
						divtst.innerHTML += '    <td width="1000"><span style="width:93%px;height:450px;overflow-x:hidden;overflow-y:auto;">';
//					divtst.innerHTML += '<div style="position:absolute; left:0cm; top:0cm;  width:680" ><center><strong><font size=4 face="Tahoma"><U>'+system_message['chkanswer']+'</U>&nbsp;&nbsp; </font></strong></center><p>');
					//	divtst.innerHTML += '<div style="position:absolute; left:0cm; top:0cm;width:1280;padding:20px 0px 0px 0px;background-color:white;text-align: center;" ><font size=5 face="Tahoma" color=black ><span style="font-size: 24"></span></font></div>';
//	divtst.innerHTML += '<div style="position:absolute; left:0cm; top:0cm;  width:680" ><span style="font-size: 28">&nbsp;&nbsp;&nbsp;'+direction+' </span></div>');
//-----1----

						for(e=0;e<random_question;e++){
							divtst.innerHTML += genQuestion((e+1),e,true,sel3[e]);	
						}

//-----2----???????????????????
						divtst.innerHTML += '</span>    </td >';
						divtst.innerHTML += '    <td valign=top>';
						divtst.innerHTML += '      <table id="tq" width="100%" border="1" cellspacing="0" cellpadding="2" bgcolor=#D8D6D7 style="display:none;">';
						/*divtst.innerHTML += '		<tr><td rowspan="2" align="center">ข้อ</td ><td colspan="'+(choice[1].length+1)+'" align="center">ตัวเลือก</td >';
						divtst.innerHTML += '		<tr>';
						for(c=0;c<choice[1].length;c++)
						{
							divtst.innerHTML += '			<td align="center">'+cChoice.charAt(c)+'</td >';
						}
							divtst.innerHTML += '			<td align="center">&nbsp;</td >';
							divtst.innerHTML += '		</tr>';
							divtst.innerHTML += outChoice;*/
							divtst.innerHTML += '        </table>';
							divtst.innerHTML += '    </td >';
							divtst.innerHTML += '  </tr></table>';
							//divtst.innerHTML += '  </div>';
		//-----2----

				document.getElementById('btleft').style.display  = 'none';
				document.getElementById('btright').style.display  = 'block';

							displayMsg(score,sel3.length*1);     /// ---------------- fix ข้อละคะแนน = 1
					}
					//document.write('<SCRIPT LANGUAGE="JavaScript">qid = 1;var agt=navigator.userAgent.toLowerCase();var browser_ie  = (agt.indexOf("msie") != -1);var browser_ns  = (navigator.appName.indexOf("Netscape") != -1); function showhide(id){ if(id == 66) id = qid>1?qid-1:qid;if(id == 99) id = qid<30?qid+1:qid;if(qid != id ) qid = id;for(i=0;i<'+random_question+';i++){document.getElementById(\'q\'+(i+1)).style.display = \'none\';document.getElementById(\'cho_\'+(i+1)).style.color = \'#000000\';document.getElementById(\'cho_\'+(i+1)).style.fontSize = 22;}document.getElementById(\'q\'+id).style.display = \'block\';document.getElementById(\'cho_\'+id).style.color = \'#FF00CC\';document.getElementById(\'cho_\'+id).style.fontSize = 22;parent.document.getElementById(\'numchoice\').innerHTML = id;showbg(id);} function moAns(tr,n){	tr.bgColor="#FFCCCC";} function muAns(tr,n){	if (n%2) bgc = "#CCFFCC";	else bgc = "#F5F5F5";	tr.bgColor=bgc;} function startPlayer(id) { if(qid != id ) {qid = id;src =  "./sound/"+id+".mp3";var wmObject = document.getElementById(\'wmp_p\');if(browser_ie) wmObject.fileName = src;if(browser_ns) wmObject.URL = src;}    }function qPlayer(id) { var wmObject = document.getElementById(\'wmp_p\');src =  "./sound/"+id+".mp3";if(browser_ie) wmObject.fileName = src;if(browser_ns) wmObject.URL = src;    }function chPlayer(chid) { var wmObject = document.getElementById(\'wmp_p\');src =  "./sound/"+chid+".mp3";if(browser_ie) wmObject.fileName = src;if(browser_ns) wmObject.URL = src;    }function showbg(n){for (i=1; i<=30 ; i++ ){ var tq = "tq"+i; if (i%2) bgc = "#E5E9E9"; else bgc = "#F5F5F5"; document.getElementById(tq).bgColor = bgc;} document.getElementById("tq"+n).bgColor = "#CCFFCC";}function showtBox(n) { document.getElementById(\'tBox_\'+n).style.display = \'block\'; } function hiddentBox(n) { document.getElementById(\'tBox_\'+n).style.display = \'none\'; }'+outAns+'</SCRIPT>');

					//if(browser_ie) document.write(wmp_ie());
					//if(browser_ns) document.write(wmp_ns());
					qid = 1;
					showhide('1');
			}else{
				alert(system_message['mustdoquiz'] +" (ข้อ "+chr.substring(3)+") ");
			}
		}
						
		function checkRadio(frm) { 
			var el = frm.elements; 
			for(var i = 0 ; i < el.length ; ++i) {  
				if(el[i].type == "radio") {   
					var radiogroup = el[el[i].name];   
					var itemchecked = false;   
					for(var j = 0 ; j < radiogroup.length ; ++j) {    
						if(radiogroup[j].checked) {	 
							itemchecked = true;	 
							break;	
						}   
					}   
					if(!itemchecked) { 
						return el[i].name;   
					}  
				} 
			} 
			return "0";
		} 



for(var i = 0; i < question.length; i++){
	random_question_array.push(i);
}
function RandomQuestion(){
	/*
	var Len = random_question;
	var j = question.length;
	var num = new Array();
	
	for (i=0; i<Len; i++){
		n = Math.floor(j  *  Math.random());
		if(num[n]) 
			i--;
		else
			num[n] = 1;
	}

	var q = new Array();
	var ch = new Array();
	var i = 0;
	for(var id in num){
		q[i] = question[id];
		ch[i] = choice[id];
		i++;
	}

	question = q;
	choice = ch;
	*/
	var currentIndex = question.length;
	var temporaryQ;
	var temporaryC;
	var temporaryR;
	var randomIndex;
	var temprandonarray = [];

	for(var i = 0; i < currentIndex; i++){
		temprandonarray.push(i);
	}

	// While there remain elements to shuffle...
	while (0 !== currentIndex) {

		// Pick a remaining element...
		randomIndex = Math.floor(Math.random() * currentIndex);
		currentIndex -= 1;

		// And swap it with the current element.
		temporaryQ = question[currentIndex];
		temporaryC = choice[currentIndex];
		temporaryR = temprandonarray[currentIndex];
		question[currentIndex] = question[randomIndex];
		choice[currentIndex] = choice[randomIndex];
		temprandonarray[currentIndex] = temprandonarray[randomIndex];
		question[randomIndex] = temporaryQ;
		choice[randomIndex] = temporaryC;
		temprandonarray[randomIndex] = temporaryR;
	}
	random_question_array = temprandonarray.slice();
}

function RandomSuit(suit){		
	Temp = new Array();		
	TempCh = new Array();		
	var Len = suit.length;		
	var j = Len;		
	
	for (var i=0; i<Len; i++)
	{				
		Temp[i] = suit[i];			
	}			
	
	for (i=0; i<Len; i++)
	{				
		Num = Math.floor(j  *  Math.random());				
		suit[i] = Temp[Num];					
		for (var k=Num; k < j; k++) 
		{						
			Temp[k] = Temp[k+1];						
		}				
		
		j--;				
	}		

	return suit;
}


//if(direction == '') direction = '????????????????';
if(direction == '') direction = system_message['direction'];
//direction = system_message['direction'];

document.write('<style type="text/css">.bgimage { background-image: url(asset/spacer.gif); background-repeat: no-repeat; background-position: top; font-family:Tahoma; font-size: 24 } .bgimage1 { background-image: url(asset/ans.gif); background-repeat: no-repeat; background-position: top; font-family:Tahoma; font-size: 24 } .choice {cursor: pointer} @font-face {    font-family: \'Tahoma\';    src: url(\'thsarabunnew_bold-webfont.eot\');    src: url(\'thsarabunnew_bold-webfont.eot?#iefix\') format(\'embedded-opentype\'),         url(\'thsarabunnew_bold-webfont.woff\') format(\'woff\'),         url(\'thsarabunnew_bold-webfont.ttf\') format(\'truetype\'),         url(\'thsarabunnew_bold-webfont.svg#Tahoma\') format(\'svg\');    font-weight: normal;    font-style: normal;}font{	font-family: \'Tahoma\';	font-size: 24;}</style>');
document.write('<a name="top"></a>');
document.write('<form name="frmexam" method="post">');				
document.write('<div id="divTest" style="position:absolute;left:0.0cm; top:0.0cm; z-index:1;width:100% " >');

//-----1----..........................
	document.write('<table width="100%" border="0" cellspacing="0" cellpadding="0">');
	document.write('  <tr> ');
	document.write('    <td width="1000"><span style="width:100%px;height:450px;overflow-x:hidden;overflow-y:auto;">');
	document.write('<div style="position:absolute; left:0cm; top:0cm; width:100%;padding:20px 0px 0px 0px;text-align: center;"><font size=5 face="Tahoma" color=black ><span style="font-size: 24">'+direction+' </span> </font></div>');
//-----1----
//alert(direction);
if(testformat==2){
	document.write('<table width="100%" border="0" cellspacing="0" cellpadding="0">');
	document.write('  <tr bgcolor=#FBFBFB> ');
	document.write('    <td  width=50 align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">'+tf_label_true+'</font></td>');
	document.write('    <td  width=50 align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">'+tf_label_false+'</font></td>');
	document.write('    <td  align="center">&nbsp;</td>');
	document.write('  </tr>');
}

if(shuffle_question) RandomQuestion();

for(i=0;i<random_question;i++){
	if(random_choice) choice[i] = RandomSuit(choice[i]);
	document.write(genQuestion((i+1),i,false,0));
}

//-----2----..........................
	document.write('</span>    </td >');
	document.write('    <td>');
//	document.write('<CENTER><BR><input type="button" name="Submit" value="ส่งตรวจ" onclick="checkAnswer(document.frmexam)"></CENTER>');
	document.write('<IMG SRC="asset/spacer.gif" WIDTH="1" HEIGHT="5"><table id="tq" width="100%" border="1" cellspacing="0" cellpadding="2" bgcolor=#D8D6D7 style="display:none;">');
	document.write('		<tr><td rowspan="2"  align="center">ข้อ</td ><td colspan="'+choice[1].length+'" align="center">ตัวเลือก</td >');
	document.write('		<tr>');
		for(c=0;c<choice[1].length;c++)
		{
			document.write('			<td align="center">'+cChoice.charAt(c)+'</td >');
		}
	document.write('		</tr>');
	document.write(outChoice);
	document.write('        </table>');
	document.write('<CENTER><input id="submitbutton" type="button" name="Submit" value="ตรวจคำตอบ" onclick="checkAnswer(document.frmexam)" style="font-size: 20px;position:absolute;top:350px;left:450px;width:140px;display:none; "></CENTER>');




	//document.write('<CENTER><input id="submitbutton" type="button" name="Submit" value="ตรวจคำตอบ" onclick="checkAnswer(document.frmexam)" style="font-size: 20px;position:absolute;top:360px;left:250px;width:140px;display:none;"></CENTER>');
	document.write('    </td >');
	document.write('  </tr></table>');
//-----2----

document.write('</div>');
document.write('</form>');
//alert(outChoice);

//document.write("<div  id=btleft onclick=\"javascript: showhide('66')\" style=\"position:absolute;cursor: pointer;display:none;left:480px;top:406px;z-index:999999\"><IMG SRC=\"asset/prev.gif\" BORDER=\"0\" align=\"middle\"  title=\"ย้อนกลับ\" width=30 height=30></div>&nbsp;&nbsp;<div id=skin style='position:absolute;z-index:3;color:#000000;font-size: 24px;padding:10px 20px 10px 20px;font-family:Tahoma;position:absolute; left:522px;top:403px;z-index:999999'><B>ข้อที่ <span id='numchoice'>1</span>/"+random_question+"</B></div>&nbsp;&nbsp;<div  id=btright onclick=\"javascript: showhide('99')\" style=\"position:absolute; cursor: pointer; left:640px;top:406px;z-index:999999\"><IMG SRC=\"asset/next.gif\" BORDER=\"0\" align=\"middle\" title=\"ถัดไป\" width=30 height=30></div>");

//document.write("<span id=skin style='position:absolute;left:280px;top:435px;z-index:999999'><span id=btleft onclick=\"javascript: showhide('66')\" style=\"cursor: pointer;\"><IMG SRC=\"asset/prev.gif\" BORDER=\"0\" align=\"middle\"  title=\"ย้อนกลับ\" width=30 height=30></span>&nbsp;&nbsp;<span id=skin style='z-index:3;color:#000000;font-size: 24px;padding:10px 20px 10px 20px;font-family:Tahoma;position:relative;top:8px;'><B>ข้อที่ <span id='numchoice'>1</span>/"+random_question+"</B></span>&nbsp;&nbsp;<span  id=btright  onclick=\"javascript: showhide('99')\" style=\"cursor: pointer;\"><IMG SRC=\"asset/next.gif\" BORDER=\"0\" align=\"middle\" title=\"ถัดไป\" width=30 height=30></span></span>");

document.write("<div  id=btleft onclick=\"javascript: showhide('66')\" style=\"position:absolute;cursor: pointer;display:none;left:300px;top:395px;z-index:999999\"><IMG SRC=\"asset/prev.gif\" BORDER=\"0\" align=\"middle\"  title=\"ย้อนกลับ\" width=30 height=30></div>&nbsp;&nbsp;<div id=skin style='position:absolute;z-index:3;color:#000000;font-size: 20px; font-family:Tahoma;position:absolute; left:325px;top:400px; width:90px; z-index:999999; padding-top: 0px'><center><B>ข้อที่ <span id='numchoice'>1</span>/"+random_question+"</B></center></div>&nbsp;&nbsp;<div  id=btright onclick=\"javascript: showhide('99')\" style=\"position:absolute; cursor: pointer; left:430px;top:395px;z-index:999\"><IMG SRC=\"asset/next.gif\" BORDER=\"0\" align=\"middle\" title=\"ถัดไป\" width=30 height=30></div>");

function checkAnswer2(frm){
			var chr = checkRadio(frm);
			return parseInt(chr.substring(3));
}

var currentnumq = 0;
function showhide(id){ //alert(qid);
	var chkanscurrent = false;
	var lastdoneq = 0;
	if(id == 99 && qid<random_question){
		lastdoneq = checkAnswer2(document.frmexam);
	}
	else{
		chkanscurrent = true;
	}
	currentnumq = qid;
	if(isNaN(lastdoneq)){
		lastdoneq = random_question;
	}
	//alert(currentnumq + " " + lastdoneq);
	if(lastdoneq > currentnumq){
		chkanscurrent = true;
	}
	else{
		if(lastdoneq != 0 && !isNaN(lastdoneq) && id != 66)
			alert("กรุณาทำข้อสอบข้อที่ "+lastdoneq+" ด้วยค่ะ");
	}
	if(chkanscurrent){
	if(id == 66) id = qid>1?qid-1:qid;
	if(id == 99) id = qid<random_question?qid+1:qid;
	if(qid != id ) qid = id;
		for(i=0;i<random_question;i++){
			document.getElementById('q'+(i+1)).style.display  = 'none';
			if(!chkans2){
				document.getElementById('cho_'+(i+1)).style.color  = '#000000';
				document.getElementById('cho_'+(i+1)).style.fontSize     = 22;
			}
			//parent.document.getElementById('numq_'+(i+1)).style.color = "#000000";
		}
		document.getElementById('q'+id).style.display  = 'block';
		if(!chkans2){
			document.getElementById('cho_'+id).style.color  = '#FF00CC';
			document.getElementById('cho_'+id).style.fontSize   = 22;
		}
		//parent.document.getElementById('numq_'+id).style.color = "#0880FA";
		document.getElementById('numchoice').innerHTML = id;

			if(id == 1){
				document.getElementById('btleft').style.display  = 'none';
			}else{
				document.getElementById('btleft').style.display  = 'block';
			}
			if(id == random_question){
				document.getElementById('btright').style.display  = 'none';
			}
			else{
				document.getElementById('btright').style.display  = 'block';
			}

		if(document.getElementById('submitbutton') != null){
//			alert(id +":"+ random_question);
			if(id == random_question){
				document.getElementById('submitbutton').style.display  = 'block';
			}
			else{
				document.getElementById('submitbutton').style.display  = 'none';
			}
		}
	//	startPlayer(id);
		if(!chkans2){
			showbg(id);
		}
	}
} 

function showbg(n){

	for (i=1; i<=random_question ; i++ )
	{
		var tq = "tq"+i;
		if (i%2) bgc = "#E5E9E9";
		else bgc = "#F5F5F5";

		document.getElementById(tq).bgColor = bgc;
	}
	document.getElementById("tq"+n).bgColor = "#CCFFCC";
}

var agt=navigator.userAgent.toLowerCase();
var browser_ie  = (agt.indexOf("msie") != -1);
var browser_ns  = (navigator.appName.indexOf("Netscape") != -1);

//alert(browser_ie);
//alert(browser_ns);
//if(browser_ie) document.write(wmp_ie());
//if(browser_ns) document.write(wmp_ns());

	function startPlayer(id) { //alert(qid+":"+id);
		if(qid != id ) {
			qid = id;
			src =  "./sound/"+id+".mp3";

			var wmObject = document.getElementById('wmp_p');
			if(browser_ie) wmObject.fileName = src;
			if(browser_ns) wmObject.URL = src;
		}
    }

	function qPlayer(id) { //alert(id);
		var wmObject = document.getElementById('wmp_p');
		src =  "./sound/"+id+".mp3";
		if(browser_ie) wmObject.fileName = src;
		if(browser_ns) wmObject.URL = src;
    }
	function chPlayer(chid) { 
		var wmObject = document.getElementById('wmp_p');
		src =  "./sound/"+chid+".mp3";
		if(browser_ie) wmObject.fileName = src;
		if(browser_ns) wmObject.URL = src;
    }

	function wmp_ns() {
	s = '<object id="wmp_p" type="application/x-ms-wmp" width="0" height="0" >';
	s += '<param name="autostart" value="true" />';
	s += '<param name="volume" value="80" />';
	s += '<param name="URL" value="" />';
	s += '</object>';
	return s;
    }

	function wmp_ie() {
	var fb_sound = "";
	
	var s = '';
	s += '<OBJECT ID="wmp_p" name="wmp_p" classid="CLSID:22D6F312-B0F6-11D0-94AB-0080C74C7E95" ';
	s += 'codebase="http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701" ';
	s += 'standby="Loading Microsoft? Windows? Media Player components..." ';
	s += 'type="application/x-oleobject" width="1" height="1">';
	s += '<PARAM NAME="FileName" value="'+fb_sound+'">';
	s += '<param name="ShowControls" value="1">';
	s += '<param name="ShowPositionControls" value="0">';
	s += '<param name="ShowAudioControls" value="1">';
	s += '<param name="ShowTracker" value="0">';
	s += '<param name="ShowDisplay" value="0">';
	s += '<param name="ShowStatusBar" value="1">';
	s += '<param name="AutoSize" value="0">';
	s += '<param name="ShowGotoBar" value="0">';
	s += '<param name="ShowCaptioning" value="0">';
	s += '<param name="AutoStart" value="1">';
	s += '<param name="AnimationAtStart" value="0">';
	s += '<param name="TransparentAtStart" value="0">';
	s += '<param name="AllowScan" value="1">';
	s += '<param name="EnableContextMenu" value="1">';
	s +='<param name="Volume" value="80">';
	s += '<param name="ClickToPlay" value="0">';
	s += '<EMBED type="application/x-mplayer2" ';
	s += 'pluginspage="http://www.microsoft.com/Windows/MediaPlayer/" ';
	s += 'src="'+fb_sound+'"	';
	s += 'name="wmp_p"	';
	s += 'id="wmp_p"	';
	s += 'width=1	';
	s += 'height=1	';
	s += 'autostart=0 ';
	s +='Volume=80 ';
	s += 'showcontrols=1	showpositioncontrols=0	showstatusbar=0	showcaptioning=0>';
	s += '</EMBED>';
	s += '</OBJECT>';
//alert(s);
	return s;
}


//----- ......................
function moAns(tr,n){
	tr.bgColor='#FFCCCC';
}
function muAns(tr,n){
	if (n%2) bgc = "#CCFFCC";
	else bgc = "#F5F5F5";
	tr.bgColor=bgc;
}
function setAns(n,c){
	var Ans = "url(asset/ans.gif)";
	var cAns = "url(asset/spacer.gif)";
//alert(n+":"+c+":"+cAns+":"+choice[n-1].length+":"+question[n-1]);
	for(var i=0; i<choice[n-1].length; i++) {
		document.getElementById('ch_'+n+'_'+i).style.backgroundImage = cAns;
		document.getElementById('tch_'+n+'_'+i).innerHTML = "<img src=asset/c.gif>";
	}
	elm = eval("document.frmexam.ch_"+n);
	elm[c].checked = true;
	document.getElementById('ch_'+n+'_'+c).style.backgroundImage = Ans;
	document.getElementById('tch_'+n+'_'+c).innerHTML = "<img src=asset/m.gif>";
//	alert(n+":"+c);
}
function AtoT(data){
	var cNo=new Array("๐","๑","๒","๓","๔","๕","๖","๗","๘","๙","๑๐");
	var outdata = "";
	data += '';

	for(i=0;i<data.length;i++){
		outdata += cNo[data.substr(i,1)];
	}
	return outdata;
}

   function showtBox(n) { document.getElementById('tBox_'+n).style.display = 'block'; }
   function hiddentBox(n) { document.getElementById('tBox_'+n).style.display = 'none'; }

showhide('1');
//-------------------


/*
var fb_range = new Array();
fb_range[0] = new Array();
fb_range[0][0] = 0;
fb_range[0][1] = 100;
fb_range[0][2] = 'aaaaa';
fb_range[0][3] = 'asset/';
fb_range[0][4] = 'aaaaaa.wma';

document.write(codeMediaFeedback('55'));
*/




function Feedback(score){
	var show = '';
	var scr = Math.floor(score);
	if(!isNaN(scr)){
		if(typeof(fb_range) != 'undefined'){

			for(var i=0;i<fb_range.length;i++){
				if((fb_range[i][0] == scr) || (fb_range[i][1] == 1) || ((fb_range[i][0] <= scr) && (fb_range[i][1] >= scr))){

					if(fb_range[i][4] != ''){
						var fb_sound = fb_range[i][3]+fb_range[i][4];
						var fb_sound_holder = sound(fb_sound);
						var fb_layer = drawLayer(fb_sound_holder,'ContentHolderFB',0, 0, 0, 0, 2, 0);
						document.body.innerHTML += fb_layer;
					}

					if(fb_range[i][2] != ''){ 
//						alert(fb_range[i][2]);
						show = fb_range[i][2];
					}

					break;
				}
			}
		}
	}

//	return (show)?true:false;
	return show;
}


function codeMediaFeedback(v){
	var fb_sound = fb_range[v][3]+fb_range[v][4];
	
	var s = '';
	s += '<OBJECT ID="MediaPlayerFB'+v+'" classid="CLSID:22D6F312-B0F6-11D0-94AB-0080C74C7E95" ';
	s += 'codebase="http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701" ';
	s += 'standby="Loading Microsoft? Windows? Media Player components..." ';
	s += 'type="application/x-oleobject" width="1" height="1">';
	s += '<PARAM NAME="FileName" value="'+fb_sound+'">';
	s += '<param name="ShowControls" value="1">';
	s += '<param name="ShowPositionControls" value="0">';
	s += '<param name="ShowAudioControls" value="1">';
	s += '<param name="ShowTracker" value="0">';
	s += '<param name="ShowDisplay" value="0">';
	s += '<param name="ShowStatusBar" value="1">';
	s += '<param name="AutoSize" value="0">';
	s += '<param name="ShowGotoBar" value="0">';
	s += '<param name="ShowCaptioning" value="0">';
	s += '<param name="AutoStart" value="0">';
	s += '<param name="AnimationAtStart" value="0">';
	s += '<param name="TransparentAtStart" value="0">';
	s += '<param name="AllowScan" value="1">';
	s += '<param name="EnableContextMenu" value="1">';
	s +='<param name="Volume" value="100">';
	s += '<param name="ClickToPlay" value="0">';
	s += '<EMBED type="application/x-mplayer2" ';
	s += 'pluginspage="http://www.microsoft.com/Windows/MediaPlayer/" ';
	s += 'src="'+fb_sound+'"	';
	s += 'name="MediaPlayerFB'+v+'"	';
	s += 'width=1	';
	s += 'height=1	';
	s += 'autostart=0 ';
	s +='Volume=100 ';
	s += 'showcontrols=1	showpositioncontrols=0	showstatusbar=0	showcaptioning=0>';
	s += '</EMBED>';
	s += '</OBJECT>';

	return s;
}



function displayMsg(score,total){
	var isoverlimitquizzed = false;
	var isAttempt = false;
	var isEmptyData = false;
	if((window.location.protocol == "http:" || window.location.protocol == "https:") && typeof(parent.parent.isoffline) != "undefined" && typeof(parent.parent.tincan) != "undefined" && typeof(parent.parent.sendCurrentState) != "undefined" && typeof(parent.parent.checkCurrentOverLimitquizzed) != "undefined" && typeof(parent.parent.isCurrentAttempted) != "undefined" && typeof(parent.parent.isEmptyState) != "undefined"){
		isEmptyData = parent.parent.isEmptyState();
		if(!isEmptyData){
			var newData = parent.parent.sendCurrentState();
			if(!newData){
				return;
			}
			isoverlimitquizzed = parent.parent.checkCurrentOverLimitquizzed();
			isAttempt = parent.parent.isCurrentAttempted();
		}
	}
	var test_result = "failed";
	var scr = Math.floor((score/total)*100);

	/*
	var msg = '?????????? '+score+' ???\n???????? '+total+' ???';
	msg+='\n???? '+scr+'%';

	if(!thai) msg = 'Your mark is '+scr+' %';
	*/
	
	var msg = system_message['score'];
	msg = replaceAll(msg, '{score}', score);
	msg = replaceAll(msg, '{total_score}', total);
	msg = replaceAll(msg, '{pc_score}', scr);

/*
	if(parent.usescorm){
		if(score_save){
			parent.doLMSSetValue("cmi.core.score.raw",scr);
			parent.doLMSSetValue("cmi.suspend_data",suspend_data);
			parent.doLMSCommit();
		}
	}
*/

	var fb_msg = Feedback(scr);
	if(fb_msg != '') msg = fb_msg + '\n\n'+msg;

	alert(msg);

	if(isEmptyData){
		alert("ระบบจะไม่จัดเก็บข้อมูลการสอบของคุณในครั้งนี้\nเนื่องจากคุณทำแบบทดสอบในหน้านี้ครบจำนวนครั้งที่กำหนดแล้ว");
		if((window.location.protocol == "http:" || window.location.protocol == "https:") && typeof(parent.parent.isoffline) != "undefined" && typeof(parent.parent.tincan) != "undefined" && typeof(parent.parent.forceExit) != "undefined"){
			parent.parent.forceExit();
		}
		return;
	}
	
	if(!isAttempt){
//		alert("ระบบจะไม่จัดเก็บข้อมูลการสอบของคุณในครั้งนี้\nเนื่องจากคุณต้องเรียนบทเรียนก่อนหน้านี้ให้ผ่านก่อน");
		return;
	}

	var temporigin = [];

	//console.log(random_question_array);

	//console.log(question_answer);
	if(!isoverlimitquizzed){
		if(scr < percentmasteryscore){
			var msgalert = '';
			msgalert += 'คุณยังทำแบบทดสอบไม่ผ่านเกณฑ์ '+percentmasteryscore+'%';
			/*for(var i = 0; i < question_wrong.length; i++){
				var chkduporigin = false;
				for(var tmp = 0; tmp < temporigin.length; tmp++){
					if(temporigin[tmp] == question_origin_index[random_question_array[question_wrong[i]]]){
						chkduporigin = true;
					}
				}
				if(!chkduporigin){
					temporigin.push(question_origin_index[random_question_array[question_wrong[i]]]);
				}
			}
			for(var a = 0; a < temporigin.length; a++){
				for(var b = 1; b < (temporigin.length-a); b++){
					if(temporigin[b-1] > temporigin[b]){
						var temp = temporigin[b-1];
						temporigin[b-1] = temporigin[b];
						temporigin[b] = temp;
					}
				}
			}
			for(var i = 0; i < temporigin.length; i++){
				msgalert += '\n- '+question_origin_name[temporigin[i]];
			}*/
			/*if((window.location.protocol == "http:" || window.location.protocol == "https:") && typeof(parent.parent.isoffline) != "undefined" && typeof(parent.parent.tincan) != "undefined" && typeof(parent.parent.getCurrentPageNumberQuizzed) != "undefined"){
				msgalert += 'หากต้องการทำแบบทดสอบอีกครั้ง\nคุณสามารถคลิกเลือก "แบบทดสอบ" ได้จากเมนูด้านซ้าย';
				alert(msgalert);
			}*/
			alert(msgalert);
		}

		if((window.location.protocol == "http:" || window.location.protocol == "https:") && typeof(parent.parent.isoffline) != "undefined" && typeof(parent.parent.tincan) != "undefined" && typeof(parent.parent.setCurrentPageScore) != "undefined" && typeof(parent.parent.getCurrentPagePassedStatus) != "undefined" && typeof(parent.parent.sendCurrentPagePassedStatement) != "undefined" && typeof(parent.parent.sendAllFullModifyStatement) != "undefined" && typeof(parent.parent.sendAllFullModifyStatementAsync) != "undefined" && typeof(parent.parent.checkReset) != "undefined" && typeof(parent.parent.sendCurrentState) != "undefined" && typeof(parent.parent.setCurrentState) != "undefined"){
			/*if(!parent.parent.isoffline){
				for(var i = 0; i < question_answer.length; i++){
					var tmptext = '';
					var tmpresult = 'ผิด';
					if(question_answer[i][0] == question_answer[i][1]){
						tmpresult = 'ถูก';
					}
					tmptext += 'ข้อ '+(random_question_array[i]+1)+'. ตอบ '+cChoice.charAt(question_answer[i][0])+'. ผลลัพธ์ '+tmpresult+'';
					//alert(tmptext);
					parent.parent.sendAllFullModifyStatementAsync("http://adlnet.gov/expapi/verbs/answered",tmptext,"answered");
				}
			}*/
			if(!parent.parent.isoffline){
				parent.parent.sendCurrentPagePassedStatement(scr >= percentmasteryscore,score,total,scr);
			}
			if(scr >= percentmasteryscore){
				parent.parent.sendExperiencedStatement();
				//alert("คุณเรียนผ่านหลักสูตรนี้เรียบร้อยแล้ว");
			}
			parent.parent.setCurrentPageScore(score,total,scr);
			//parent.parent.checkReset();
			parent.parent.setCurrentState();
			var newData = parent.parent.sendCurrentState();
			if(!newData){
				return;
			}
			/*if(scr >= percentmasteryscore){
				alert("ขอแสดงความยินดี\nคุณเรียนผ่านหลักสูตรนี้แล้ว");
				parent.parent.doPassed();
			}
			else{
				if(parent.parent.getFailed()){
					alert("ขอแสดงความเสียใจ\nคุณเรียนไม่ผ่านหลักสูตรนี้");
					parent.parent.doUnload();
					parent.parent.goExit();
				}
			}*/
		}
	}
	else{
		alert("ระบบจะไม่จัดเก็บข้อมูลการสอบของคุณในครั้งนี้\nเนื่องจากคุณทำแบบทดสอบในหน้านี้ครบจำนวนครั้งที่กำหนดแล้ว");
	}

}



function setSystemMsg(){
	system_message = new Array();
	system_message['chkanswer'] = (thai)?'ตรวจคำตอบ':'Check Answer';
	system_message['showanswer'] = (thai)?'เฉลยคำตอบ':'Show Answer';
	system_message['remark'] = (thai)?'หมายเหตุ: ตัวอักษรสีแดง คือคำตอบที่ถูกต้อง':'Remark: Red Sentence is Correct Answer.';
	system_message['mustdoquiz'] = (thai)?'กรุณาทำข้อสอบให้ครบทุกข้อ':'Please select answer.';
	system_message['suspend_data'] = (thai)?new Array('บันทึกข้อมูลเรียบร้อยแล้ว', 'ข้อความควรมีความยาวรวมทั้งหมดไม่เกิน 4096 ตัวอักษร'):new Array('Already saved data','The data must not be length more than 4096 characters');
	system_message['viewscore'] = (thai)?'คลิกเพื่อดูคะแนน':'Click to view your score';
	system_message['close'] = (thai)?'ปิดหน้าต่าง':'Close Window';
	system_message['next'] = (thai)?'ถัดไป':'Next';

	system_message['score'] = thai?'คุณทำข้อสอบได้ {score} คะแนน\nจากทั้งหมด {total_score} คะแนน\nคิดเป็น {pc_score}%':'Your mark is {pc_score}%';
	system_message['avg'] = thai?'คุณได้คะแนนเฉลี่ย {pc_score}%\nจากข้อสอบทั้งหมด {total_suit} ชุด':'Average Score: {pc_score}%\nFrom {total_suit} exercises';
	system_message['mustdo'] = thai?'คุณยังไม่ได้ทำข้อสอบ':'You must do:';
	system_message['direction'] = thai?'จงเลือกคำตอบที่ถูกต้อง':'Please choose the correct answer';
	system_message['finishquiz'] = thai?'เมื่ออ่านเฉลยจบแล้ว ให้กดปุ่ม ปิด แล้วรอการประมวลผลจากระบบ':'เมื่ออ่านเฉลยจบแล้ว ให้กดปุ่ม ปิด แล้วรอการประมวลผลจากระบบ';
}

setSystemMsg();

function replaceAll(text, tag, value){
	while((text.indexOf( tag ) != -1) != false)
		text = text.replace( tag , value );
	return text;
}
