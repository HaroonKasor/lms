(function (win, doc) {

  /** Below this point the scaling takes effect. */
  var BREAKPOINT = 2500;
  
  /**
   * The `window.resize`-callback gets throttled
   * to an interval of 30ms.
  */
  var THROTTLE = 30;
  
  /** Just the declaration. Definition comes later. */
  var IFRAME_HEIGHT;

  var iframe = doc.getElementsByTagName('iframe')[0],
      timestamp = 0;
  
  /** Defining the inital iframe-height. */
  IFRAME_HEIGHT = parseInt(getComputedStyle(iframe).height, 10);
  
  /**
   * Takes an object with CSS-transform-properties
   * and generates a cross-browser-ready style string.
   *
   * @param  {Object} obj
   * @return {String}
   */
  function transformStr(obj) {
    var obj = obj || {},
        val = '',
        j;
    for ( j in obj ) {
      val += j + '(' + obj[j] + ') ';
    }
    val += 'translateZ(0)';
    return '-webkit-transform: ' + val + '; ' +
            '-moz-transform: ' + val + '; ' +
            'transform: ' + val;
  }
  
  /**
   * Scaling the iframe if necessary.
   *
   * @return {Function}
   */
  function onResize() {
  
    var now = +new Date,
        winWidth = win.innerWidth,
        noResizing = winWidth > BREAKPOINT,
        scale,
        width,
        height,
        offsetLeft;
    
    if ( now - timestamp < THROTTLE || noResizing ) {
      /** Remove the style-attr if we're out of the "scaling-zone". */
      noResizing && iframe.hasAttribute('style') && iframe.removeAttribute('style');
      return onResize;
    }
    
    timestamp = now;
    
    /**
     * The required scaling; using `Math.pow` to get
     * a safely small enough value.
     */
    scale = Math.pow(winWidth / (BREAKPOINT/2) , 0.8);
    
    /**
     * To get the corresponding width that compensates
     * the shrinking and thus keeps the width of the
     * iframe consistent, we have to divide 100 by the
     * scale. This gives us the correct value in percent.
     */
    width = 100 / scale;
    
    /**
     * We're using the initial height and the compen-
     * sating width to compute the compensating height
     * in px.
     */
    height = IFRAME_HEIGHT + 365 / scale;
    
    /**
     * We have to correct the position of the iframe,
     * when changing its width.
     */
    offsetLeft = (width - 100) / 2;
	

//	alert(winWidth+":"+scale+" : "+offsetLeft+":"+height);

	if (winWidth <= 1280)
	{

	/** Setting the styles. */
    iframe.setAttribute('style', transformStr({
      scale: scale,
      translateX: '-' + offsetLeft + '%'
    }) + ';' + 'height: ' + height + 'px');

    //alert(offset(document.getElementById('nolpifrm')));
	document.getElementById("qq").style.top = 148 * (scale * scale) + 'px';
	document.getElementById("qq").style.left = 110 * (scale * scale) + 'px';
	document.getElementById("nolpifrm").style.height = height + 'px';
	//document.getElementById("video-overlay").style.top = 400 * scale + 'px';
	//document.getElementById("qq").style.top = offset(document.getElementById('qq')).top * scale + 'px';
	document.getElementById("skin").style.width =  winWidth+'px';
//	document.getElementById("mskin").style.marginLeft  =  '-' + (winWidth/2) +'px';
	document.getElementById("mskin").style.marginLeft  =  0 +'px';
//		alert(document.getElementById("qq").style.top+":"+document.getElementById("qq").style.left);
	}else{
//		alert(document.getElementById("qq").style.top+":"+document.getElementById("qq").style.left);

		iframe.setAttribute('style', transformStr({
		  scale: 1,
		  translateX: '-' + 0 + '%'
		}) + ';' + 'height: ' + 515 + 'px');

		
		document.getElementById("qq").style.top = '148px';
		document.getElementById("qq").style.left = '110px';
		document.getElementById("nolpifrm").style.height = '515px';
		document.getElementById("skin").style.width =  '1280px';
		document.getElementById("mskin").style.marginLeft  =  '' + ((winWidth-1280)/2) +'px';
	}
//	alert(document.getElementById("skin").style.width +":"+ document.getElementById("mskin").style.marginLeft );
    return onResize;
  
  }
  
  /** Listening to `window.resize`. */
  win.addEventListener('resize', onResize(), false);
function offset(el) {
    var rect = el.getBoundingClientRect(),
    scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
    scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    return { top: rect.top + scrollTop, left: rect.left + scrollLeft }
}

})(window.self, document);