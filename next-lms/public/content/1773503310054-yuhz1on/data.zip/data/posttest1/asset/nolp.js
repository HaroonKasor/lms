var scoid = '968';
var pagenow = 1;
var numpage = 1;
var w = 98;
var h = 4;
var content_w = 928;
var content_h = 498;
var topic = 'Ẻ���ͺ��͹���¹';
var nolp_lesson_mode = 'normal';
var display = true;
var numtest = 1;
var offline = true;
usescorm = (offline)?false:true;
var wm_media = 6;
var listpage_w = 0;
var listpage_h = 0;

var use_media_server = false;
var media_server = '';
if((typeof(media_server) != "undefined") && (media_server != '')){
	if(media_server.substring( (media_server.length - 1) ) != '/') media_server += '/';
	media_server += scoid+'/';
}

if(!offline && use_media_server && media_server ==''){
	var media_pp = location.pathname.split('/');
	media_pp.pop();
	var pathname = media_pp.join('/');

	media_server = 'mms://'+location.host+pathname;
	if(media_server.substring( (media_server.length - 1) ) != '/') media_server += '/';
}


var thai = true;


if (window.location.search.length > 0){
      var strQuery = window.location.search.substring(1);
	  var arrQuery = strQuery.split(';');
	  for (var i=0;i<arrQuery.length;i++){
	     var arr_value = arrQuery[i].split('=');
		 var arrval = arr_value[0].toLowerCase();
		 if((arr_value[1] != null) && (arr_value[1] != '')){
			 switch(arrval){
				 case "page":
					 pagenow = arr_value[1];
					 break;
			 }
		 }
	  } 
   }



if(!offline){
	var resultsco = "true";//startSCO();
	usescorm = display = (resultsco == "true")?true:false;
}

if(display){

	var score_suit = [];

//	document.write("<span id=skin style='position:absolute;width:1000px;height:29px;left:0px;top:611px;z-index:1'><img src=\"asset/256_3012_1.jpg\" border=0></span><span id=skin style='position:absolute;width:14px;height:499px;left:986px;top:113px;z-index:1'><img src=\"asset/256_3011_1.jpg\" border=0></span><span id=skin style='position:absolute;width:58px;height:499px;left:0px;top:113px;z-index:1'><img src=\"asset/256_3010_1.jpg\" border=0></span><span id=skin style='position:absolute;width:1000px;height:73px;left:0px;top:40px;z-index:1'><img src=\"asset/256_3009_1.jpg\" border=0></span><span id=skin style='position:absolute;width:32px;height:40px;left:968px;top:0px;z-index:2'><img src=\"asset/260_3026_4.jpg\" border=0 width=\"32\" height=\"40\" style=\"cursor:pointer\" alt=\"Exit\" onclick=\"goPage('exit')\" ></span><span id=skin style='position:absolute;width:32px;height:40px;left:936px;top:0px;z-index:2'><img src=\"asset/260_3025_3.jpg\" border=0 width=\"32\" height=\"40\" style=\"cursor:pointer\" alt=\"Next page\" onclick=\"goPage('next')\" ></span><span id=skin style='position:absolute;width:928px;height:498px;left:58px;top:113px;z-index:4'><iframe name=\"nolpifrm\" id=\"nolpifrm\" src=\"about:blank\" width=\"928\" height=\"498\" scrolling=\"auto\" frameborder=\"0\"></iframe></span><span id=skin style='position:absolute;width:32px;height:40px;left:904px;top:0px;z-index:2'><img src=\"asset/260_3023_2.jpg\" border=0 width=\"32\" height=\"40\" style=\"cursor:pointer\" alt=\"Previous page\" onclick=\"goPage('back')\" ></span><span id=skin style='position:absolute;width:1000px;height:40px;left:0px;top:0px;z-index:1'><img src=\"asset/256_2983_1.jpg\" border=0></span>");


	//document.write("<span id=skin style='position:absolute;width:1000px;height:70px;left:0px;top:540px;z-index:1'><img src=\"asset/256_2991_1.jpg\" border=0></span><span id=skin style='position:absolute;width:14px;height:467px;left:988px;top:73px;z-index:1'><img src=\"asset/256_2990_1.jpg\" border=0></span><span id=skin style='position:absolute;width:58px;height:467px;left:0px;top:73px;z-index:1'><img src=\"asset/256_2989_1.jpg\" border=0></span><span id=skin style='position:absolute;width:1024px;height:130px;left:0px;top:0px;z-index:99'><img src=\"asset/380_6771_1.jpg\" border=0></span><span id=skin style='position:absolute;width:775px;height:510px;left:125px;top:130px;z-index:4'><iframe name=\"nolpifrm\" id=\"nolpifrm\" src=\"about:blank\" width=\"775\" height=\"510\" scrolling=\"auto\" frameborder=\"0\"></iframe></span>");
	
	document.write("<div style='position:absolute;top:0px;left: 50%;margin-left: -490px;'>");

	document.write("<span id=skin style='position:absolute;width:980px;height:650px;left:0px;top:0px;z-index:1'><img src=\"asset/bg.png\" border=0></span><span id=skin style='position:absolute;width:800;height:460px;left:150px;top:90px;z-index:4'><iframe name=\"nolpifrm\" id=\"nolpifrm\" src=\"about:blank\" width=\"675\" height=\"460\" scrolling=\"no\" frameborder=\"0\" ></iframe></span>");

	//var txtq = '&nbsp;&nbsp;&nbsp; <span name="numq_1" id="numq_1" onclick="nolpifrm.showhide(1);" style="cursor: pointer">1</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span name="numq_2" id="numq_2" onclick="nolpifrm.showhide(2)" style="cursor: pointer">2</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span name="numq_3" id="numq_3" onclick="nolpifrm.showhide(3)" style="cursor: pointer">3</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span name="numq_4" id="numq_4" onclick="nolpifrm.showhide(4)" style="cursor: pointer">4</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span name="numq_5" id="numq_5" onclick="nolpifrm.showhide(5)" style="cursor: pointer">5</span>';
	
//	var txtq = '&nbsp;&nbsp; <span name="numq_1" id="numq_1" onclick="nolpifrm.showhide(1);" style="cursor: pointer">1</span>&nbsp;&nbsp; <span name="numq_2" id="numq_2" onclick="nolpifrm.showhide(2)" style="cursor: pointer">2</span>&nbsp;&nbsp; <span name="numq_3" id="numq_3" onclick="nolpifrm.showhide(3)" style="cursor: pointer">3</span>&nbsp;&nbsp; <span name="numq_4" id="numq_4" onclick="nolpifrm.showhide(4)" style="cursor: pointer">4</span>&nbsp;&nbsp; <span name="numq_5" id="numq_5" onclick="nolpifrm.showhide(5)" style="cursor: pointer">5</span>&nbsp;&nbsp; <span name="numq_6" id="numq_6" onclick="nolpifrm.showhide(6)" style="cursor: pointer">6</span>&nbsp;&nbsp; <span name="numq_7" id="numq_7" onclick="nolpifrm.showhide(7)" style="cursor: pointer">7</span>&nbsp;&nbsp; <span name="numq_8" id="numq_8" onclick="nolpifrm.showhide(8)" style="cursor: pointer">8</span>&nbsp;&nbsp; <span name="numq_9" id="numq_9" onclick="nolpifrm.showhide(9)" style="cursor: pointer">9</span>&nbsp;&nbsp; <span name="numq_10" id="numq_10" onclick="nolpifrm.showhide(10)" style="cursor: pointer">10</span>&nbsp;&nbsp; <span name="numq_11" id="numq_11" onclick="nolpifrm.showhide(11)" style="cursor: pointer">11</span>&nbsp;&nbsp; <span name="numq_12" id="numq_12" onclick="nolpifrm.showhide(12)" style="cursor: pointer">12</span>&nbsp;&nbsp; <span name="numq_13" id="numq_13" onclick="nolpifrm.showhide(13)" style="cursor: pointer">13</span>&nbsp;&nbsp; <span name="numq_14" id="numq_14" onclick="nolpifrm.showhide(14)" style="cursor: pointer">14</span>&nbsp;&nbsp; <span name="numq_15" id="numq_15" onclick="nolpifrm.showhide(15)" style="cursor: pointer">15</span>&nbsp;&nbsp; <span name="numq_16" id="numq_16" onclick="nolpifrm.showhide(16)" style="cursor: pointer">16</span>&nbsp;&nbsp; <span name="numq_17" id="numq_17" onclick="nolpifrm.showhide(17)" style="cursor: pointer">17</span>&nbsp;&nbsp; <span name="numq_18" id="numq_18" onclick="nolpifrm.showhide(18)" style="cursor: pointer">18</span>&nbsp;&nbsp; <span name="numq_19" id="numq_19" onclick="nolpifrm.showhide(19)" style="cursor: pointer">19</span>&nbsp;&nbsp; <span name="numq_20" id="numq_20" onclick="nolpifrm.showhide(20)" style="cursor: pointer">20</span>&nbsp;&nbsp; <span name="numq_21" id="numq_21" onclick="nolpifrm.showhide(21)" style="cursor: pointer">21</span>&nbsp;&nbsp; <span name="numq_22" id="numq_22" onclick="nolpifrm.showhide(22)" style="cursor: pointer">22</span>&nbsp;&nbsp; <span name="numq_23" id="numq_23" onclick="nolpifrm.showhide(23)" style="cursor: pointer">23</span>&nbsp;&nbsp; <span name="numq_24" id="numq_24" onclick="nolpifrm.showhide(24)" style="cursor: pointer">24</span>&nbsp;&nbsp; <span name="numq_25" id="numq_25" onclick="nolpifrm.showhide(25)" style="cursor: pointer">25</span>&nbsp;&nbsp; <span name="numq_26" id="numq_26" onclick="nolpifrm.showhide(26)" style="cursor: pointer">26</span>&nbsp;&nbsp; <span name="numq_27" id="numq_27" onclick="nolpifrm.showhide(27)" style="cursor: pointer">27</span>&nbsp;&nbsp; <span name="numq_28" id="numq_28" onclick="nolpifrm.showhide(28)" style="cursor: pointer">28</span>&nbsp;&nbsp; <span name="numq_29" id="numq_29" onclick="nolpifrm.showhide(29)" style="cursor: pointer">29</span>&nbsp;&nbsp; <span name="numq_30" id="numq_30" onclick="nolpifrm.showhide(30)" style="cursor: pointer">30</span>';

//	document.write("<span id=skin style='position:absolute;left:410px;top:605px;z-index:999999'><span onclick=\"javascript: nolpifrm.showhide('66')\" style=\"cursor: pointer;\"><IMG SRC=\"asset/prev.gif\" BORDER=\"0\" align=\"middle\"  title=\"��͹��Ѻ\" width=30 height=30></span>&nbsp;&nbsp;<span id=skin style='z-index:3;color:#FFFFFF;font-size: 16px;padding:10px 20px 10px 20px;font-family:arial;line-height:30px;position:relative;top:5px;'><B>��ͷ�� <span id='numchoice'>1</span>/10</B></span>&nbsp;&nbsp;<span onclick=\"javascript: nolpifrm.showhide('99')\" style=\"cursor: pointer;\"><IMG SRC=\"asset/next.gif\" BORDER=\"0\" align=\"middle\" title=\"�Ѵ�\" width=30 height=30></span></span>");
	document.write("</div>");

	setSystemMsg();chgPage(scoid,pagenow);startCounter();
}
